import React from 'react'
import Hero from '../components/Layout/Hero'
import { GenIcon } from 'react-icons/lib'
import GenderCollectionSection from '../components/Products/GenderCollectionSection'
import NewArrivals from '../components/Products/NewArrivals'
import ProductDetails from '../components/Products/ProductDetails'


const Home = () => {
  return (
    <div>
      <Hero/>
      <GenderCollectionSection/>
  <NewArrivals/>
  <h2 className='font-semibold underline text-2xl text-center  mb-2 '>Best Sellers.</h2>
   <ProductDetails/>
   
    </div>
  )
}

export default Home
