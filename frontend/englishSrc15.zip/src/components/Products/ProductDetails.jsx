
// import { TiMinus } from "react-icons/ti";
// import { TiPlus } from "react-icons/ti";
// import React, { useEffect } from 'react'
// const selectedProduct={
//   name:"stylish jacket",
//   price:233,
//   originalPrice:150,
//   description:"the stylish jacket perfect for any occasiion",
//   brand:"MD",
//   material:"Leather",
//   size:["s","M","L","xxl"],
//   colors:["Blue","Black","red","crimson"],
//   images:[
//     {
//       url:"https://picsum.photos/500/500?random=1",
// altText:"Jacket 1",
//     },
//       {
//       url:"https://picsum.photos/500/500?random=2",
// altText:"Jacket 2",
//     },

//   ]
// }
// const ProductDetails = () => {
//   const [mainImage,setMainImage]=useState("");
//   useEffect(()=>{
//     if(selectedProduct?.images?.length >0){
//       setMainImage(selectedProduct.images[0].url);
//     }
//   },[selectedProduct])
//   return (
//     <div className='max-w-6xl mx-auto bg-white p-8 rounded-lg'>
//       <div className='flex flex-col md:flex-row'>

// {/* <left thumbnails */}
// {/* <div className='hidden md:flex-col md:flex-col space-y-4 mr-6'>
// {selectedProduct.images.map((image, index) => (
//   <img 
//     key={image.url || index}  // Use URL first (more stable than index)
//     className="w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80 transition-opacity"
//     src={image.url} 
//     alt={image.altText || `Thumbnail ${index}`}
//     loading="lazy"  // Better performance
//   />
// ))}
// </div> */}
//  <div className='hidden md:flex-col md:flex-col space-y-4 mr-6'>
//           {selectedProduct.images.map((image, index) => (
//             <img 
//               key={image.url || index}
//               className="w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80 transition-opacity"
//               src={image.url} 
//               alt={image.altText || `Thumbnail ${index}`}
//               loading="lazy"
//               onClick={setMainImage(image.url)} //for image click it show the image 
//             />
//           ))}
//         </div>
//         {/* MAIN IMAGE .. which we click the image show*/}
//         <div className='md:w-1/2'>
//         <div className='mb-4'>
// <img 
// src={selectedProduct.images[0]?.url} 
// alt="MAin product"
//  className='w-full h-auto object-cover rounded-lg' />
      
      
//         </div>

//         </div>

//         {/* mobile thumbnails */}
//         <div className='md:hidden flex overscroll-x-scroll space-x-4 mb-4'>
//  {selectedProduct.images.map((image, index) => (
//             <img 
//               key={image.url || index}
//               className="w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80 transition-opacity"
//               src={image.url} 
//               alt={image.altText || `Thumbnail ${index}`}
//               loading="lazy"
//             />
//           ))}
//         </div>
// {/* RIGHT SIDE */}
// <div className='md:w-1/2 md:ml-10'>
// <h1 class="text-2xl md:text-3xl font-bold mb-2">{selectedProduct.name}</h1>
// <p className='text-lg textgrey-700 mb-1 line-through'>{selectedProduct.originalPrice && `${selectedProduct.originalPrice}`}</p>
//     <p className='text-xl text-grey-700 mb-2'>Rs.{selectedProduct.price}</p>
// <p className='text-xl text-grey-600 mb-2'>{selectedProduct.description}</p>
// <div className='mb-5'>
//    <p className='text-grey-600 font-bold '>Colors :</p>
//   <div className='flex gap-3 mt-2 ml-2'></div>
// {selectedProduct.colors.map((color) => {
//   return (
//     <button
//       key={color}
//       style={{ backgroundColor: color.toLowerCase() }}
//       className="h-9 w-9 ml-2 rounded-full border border-gray-300"
//     ></button>
//   );
// })}

// </div>
// {/*  */}
// <div className='flex items-center px-3 py-3 mt-2 mb-3'>
// <h4 className='text-gray-700 text-2xl text-bold'>Size:</h4>
// {selectedProduct.size.map((size =>(

//   <button className='px-4 ml-2 rounded-full border text-grey-600 py-3 '>{size}</button>
// )))}
// </div>
// {/* Quantity */}
// <div className='flex items-center py-3 px-9 mb-2'>
// <p className='text-gray-700 space-x-3 mr-2'>Quantity</p>
// <button className='px-2 py-2 bg-gray-200 mr-2 rounded text-lg'><TiPlus className="w-7"/></button><span>3</span><button className='ml-2  px-2 py-2 bg-gray-200 rounded-full py-2 text-lg'><TiMinus className="w-7" /></button>
// </div>
// <button className="bg-black text-white py-2 px-6 rounded w-full mb-4">
// Add To Cart 
// </button>
// <div className="mt-10 text-gray-700">
// <h3 className="text-xl font-bold mb-3">Characteristics:- </h3>
// <table className="w-full text-left text-sm text-gray-500">
// <tbody>
// <tr>
//   <td className="py-2">Brand : </td>
//   <td>{selectedProduct.brand}</td>
// </tr>
// <tr>
//   <td className="py-2">Material : </td>
//   <td>{selectedProduct.material}</td>
// </tr></tbody>
// </table>
// </div>


// </div>
//       </div>
//     </div>
//   )
// }

// export default ProductDetails











import React, { useEffect, useState } from 'react'
import { TiMinus, TiPlus } from "react-icons/ti";

const selectedProduct = {
  name: "stylish jacket",
  price: 233,
  originalPrice: 150,
  description: "the stylish jacket perfect for any occasiion",
  brand: "MD",
  material: "Leather",
  size: ["S", "M", "L", "XXL"],
  colors: ["Blue", "Black", "Red", "Crimson"],
  images: [
    { url: "https://picsum.photos/500/500?random=1", altText: "Jacket 1" },
    { url: "https://picsum.photos/500/500?random=2", altText: "Jacket 2" },
  ]
}

const ProductDetails = () => {

  const [mainImage, setMainImage] = useState("")
  const [quantity, setQuantity] = useState(1)

  useEffect(() => {
    if (selectedProduct?.images?.length > 0) {
      setMainImage(selectedProduct.images[0].url)
    }
  }, [])

  return (
    <div className='max-w-6xl mx-auto bg-white p-8 rounded-lg'>
      <div className='flex flex-col md:flex-row'>

        {/* LEFT THUMBNAILS */}
        <div className='hidden md:flex flex-col space-y-4 mr-6'>
          {selectedProduct.images.map((image, index) => (
            <img
              key={image.url || index}
              className="w-20 h-20 object-cover rounded cursor-pointer hover:opacity-80 transition-opacity"
              src={image.url}
              alt={image.altText || `Thumbnail ${index}`}
              loading="lazy"
              onClick={() => setMainImage(image.url)}   // ✅ FIXED
            />
          ))}
        </div>

        {/* MAIN IMAGE */}
        <div className='md:w-1/2'>
          <div className='mb-4'>
            <img
              src={mainImage} //main image - on click change 
              alt="Main product"
              className='w-full h-auto object-cover rounded-lg'
            />
          </div>
        </div>

        {/* MOBILE THUMBNAILS */}
      <div className='md:hidden flex overflow-x-scroll space-x-4 mb-4'>
  {selectedProduct.images.map((image, index) => {
    const isActive = mainImage === image.url

    return (
      <div
        key={image.url || index}
        className={`p-[2px] rounded-lg ${
          isActive
            ? " border-b-black"
            : "bg-gray-200"
        }`}
      >
        <img
          src={image.url}
          alt={image.altText || `Thumbnail ${index}`}
          onClick={() => setMainImage(image.url)}
          className="w-20 h-20 object-cover rounded-lg cursor-pointer"
        />
      </div>
    )
  })}
</div>



        {/* RIGHT SIDE */}
        <div className='md:w-1/2 md:ml-10'>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{selectedProduct.name}</h1>

          <p className='text-lg text-gray-500 mb-1 line-through'>
            Rs. {selectedProduct.originalPrice}
          </p>

          <p className='text-xl text-gray-800 mb-2'>Rs. {selectedProduct.price}</p>

          <p className='text-gray-600 mb-4'>{selectedProduct.description}</p>

          {/* COLORS */}
          <div className='mb-5'>
            <p className='text-gray-700 font-bold'>Colors:</p>
            <div className='flex gap-3 mt-2'>
              {selectedProduct.colors.map(color => (
                <button
                  key={color}
                  style={{ backgroundColor: color.toLowerCase() }}
                  className="h-9 w-9 rounded-full border border-gray-300"
                />
              ))}
            </div>
          </div>

          {/* SIZES */}
          <div className='flex items-center mb-4'>
            <h4 className='text-gray-700 text-lg font-semibold'>Size:</h4>
            {selectedProduct.size.map(size => (
              <button
                key={size}
                className='px-4 ml-2 rounded-full border text-gray-600 py-2 hover:bg-gray-100'
              >
                {size}
              </button>
            ))}
          </div>

          {/* QUANTITY */}
          <div className='flex items-center mb-4'>
            <p className='text-gray-700 mr-3'>Quantity</p>
            <button
              onClick={() => setQuantity(q => Math.max(1, q - 1))}
              className='p-2 bg-gray-200 rounded'
            >
              <TiMinus />
            </button>

            <span className='mx-3 text-lg'>{quantity}</span>

            <button
              onClick={() => setQuantity(q => q + 1)}
              className='p-2 bg-gray-200 rounded'
            >
              <TiPlus />
            </button>
          </div>

          <button className="bg-black text-white py-2 px-6 rounded w-full mb-6">
            Add To Cart
          </button>

          {/* TABLE */}
          <div className="text-gray-700">
            <h3 className="text-xl font-bold mb-3">Characteristics:</h3>
            <table className="w-full text-left text-sm">
              <tbody>
                <tr>
                  <td className="py-2">Brand:</td>
                  <td>{selectedProduct.brand}</td>
                </tr>
                <tr>
                  <td className="py-2">Material:</td>
                  <td>{selectedProduct.material}</td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  )
}

export default ProductDetails





