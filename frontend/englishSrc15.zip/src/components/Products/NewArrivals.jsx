import { Link } from "react-router-dom";
import { HiArrowLeft, HiArrowRight } from "react-icons/hi";
import React, { useRef } from "react"; // ✅ added useRef

const NewArrivals = () => {
  const scrollRef = useRef(null); // ✅ reference for scroll container

  const scroll = (direction) => {
    const container = scrollRef.current;
    const scrollAmount = 400;

    if (container) {
      container.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  const newArrivals = [
    {
      _id: "1",
      name: "Stylish Jacket",
      price: 120,
      images: [{ url: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTzJ-7mxYHkhL4mJPs91M8qmJ9f9AdRzFK-Kaky2NjEjEL04rHQADisbbacWCQSF7_F04-khcG8LI4UiEhdRNK8QEfEpAPCZIKk2dl8rUDBgzavPL6yTRP6phBzoqG9fHnc1V4SVOY&usqp=CAc", altText: "Jacket" }],
    },
    {
      _id: "2",
      name: "Casual T-Shirt",
      price: 40,
      images: [{ url: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhIVFRUVFxcVFRUVFRUVFRUVFRUWFhUVFxUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGRAQGi0lIB0vLS0rLy0rLS0tLS0tLS0rKy0tLSsrLy0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAPoAyQMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAEDBAUGBwj/xABBEAABAwEFBQUECAQFBQAAAAABAAIRAwQFEiExBkFRYXETIoGRoQcyscEjQlJigpLR8BRysuEzQ1Oi8RUkNGPC/8QAGQEBAQADAQAAAAAAAAAAAAAAAAECAwQF/8QAJBEBAAICAgICAwADAAAAAAAAAAECAxESIQQxUXEiMjMTFEH/2gAMAwEAAhEDEQA/APN2pSkEginATJ0yB05SSKBAKQKMFOSgdyJoUYURqy+JyGZ4k/opM6WsbXmUxvcBySp05J7j44939VVs9obTmQ0kZ4T3nHqQYHSFFXvk605aDq0mR05Hpkte7Nmqwu1mwcwQOJzg/pzEqKs0g/MGQfFZjr0dq09RuIRWeuMXAETA0z3xxWUTMe2MxE+ltGl0ShZsDOTEosKUIGQgpSnCBymSJRNQIhRhuUqRxTIBajTJQgeIQhSOCFoQOmUkJsKBoTQpAEiiBASwok0oAq6dcvNVm0XPdgEmeGZVmq2Qut9mdlmq52HQ5u66LVknXbfiry6Ytl2DtDhjI3aGZjmsqvsxWa7BgJnLIZa6yvomnQBHBZ9ou8F2QWnnZ0/4qT08Qr7EVmtxDPLMLItNidSjEI4L3a8rJA18F5xt2wBmQ0ylSuS0zqTJhrFdw5mwvkHlCsFV7qZ3C7icvAf3Vkrqj04bIymIRmEBKyQ2FLinlAQiHaVIAgARhyKZ5TkIHHNOiGKfEkAmlFTOCFqMlINRCTSnc1MAgUpBEQmAQNCaFIUwCCxd9jNWo2mCGl0gF0wMic4z3Lu9i7JUoWOoRDXirUExiw4SGnLfBELlNknhtsoEkAY4k6AlpDZ8SF6rccU+0pOOItqOkwO9j+kxZfzrnzT3p1+PHW3BWvae203QypUeDJmpRGGGnPPEI6LpbsvO0VLO6uQDhE5At3ToeS37Vc9GqcTm5dTmp7TZWizvawAAiAtU9w6K9PJLw2stL34WuDWuMAik5xneBnn5KpfFR77I9zqgqA4Ydhh3vCQeK7Khc1NwmPDcqd9WVjWBjGgy5sDiQ4H5Kco6JpPe5cBSYWNDSII1HM5pEqW2Edo+NA4gdAYCh3Ltj0863uTBM4IgkWqsQhC5SAJiAgBqRCNEEEQCkAhM5sokAv0UfgpKhUaCyAjlDUQtcgJyQTynhAxShLCQpGBBHKJoRFgSYEACQcvNd5sXelR4e6o4vdiaHEkkxEDPlBXEFa+y9dzKrsO9pJHHCfjBK15Y3Vtw21d6661MaBiOugGcrib+ttoaagph7gZILjOHdHLXRXW2ynXc1rg50NAbhJAk5/VIKx74s5FQM/gyGx74JA8Y39Vyw9CsR8rd2XiDTa1xOOMwRBkBc5tBerg4YOefhEhT16rKJjvYoPvOJAkQInTwXP3kSS08Rl0n9nxWWKsTZqz3mK9KJCclNCIBdjzzSmTgJygYISM0aEBAxahDlK4KPCgOUxToXBADkuzUkJ4QS6p8GSMtQuCCJo3KWmhwoZIQTpBRCqU/a8kEpISKiKBqCYvWhs3asNppzvOH8wI+JCzIW3spc5rPdUzDaOFxjXEXd0dMj+zKxt+ss6b5RpsXpYatKoX0DAdq3OOuWizbTfdojA5h0iZC72tRxNXPXlZ8+nJcUW+Xo8PiXG2ez1Kr/pNBu49VavuymGuAyaIPjotyjZwCtS67ndaH4QO79dx0A+Z5K1vPKNMbY68J3LzdzUJXst8+zmjXGKk40XQBkA5ro3ublnzBC862g2StFkkvZipj/NZm38W9njlzK7tTDzmAmCIpIhoSATymQJ+SAIilKBkoTlCHIEEkzkMFBecoiUbSkWoFKZwSaiQAQmaEiU7QgRTBPhJIAEkmABmSToAN5XouyXs1e/DVtksZqKIMPP8AOR7g5DPomhy2zOzNe3Pw0mwwGH1SO43iPvO5D01Xtl3bN0bPQFCk3ux3ifeeTq5x45DpC0rHZGUmCnTYGMaIa1oAAHIBWQFlo25qrs/HuvMcHNn1BHwWPa9l3uP+IPyk/Nd8XKN0cFr/AMNPht/2Mny42w7J0wZdif1MN8hn6rp7JYQwAABoGjQICtDojWcVrX1DXa9re5ARuUVSiDu5KxCULLbF57tL7N6FaX0PoKnAD6Jx5s+r+HLkvMb82ftFkdhrMIBya8Zsd0dx5HNfR5YqlvsLKrHU6jGvY4Q5rhIIU1A+Z4TAL0DbL2efw7HV7M8uptzNN0l7RvwuHvAc84BzK4EBSYUBCGUbkGBQMU8JQkgRam7NGmQThqTiilAUCpqRR6KQIIozWps9cVa11hRpASRic4+6xoiXHzGQ4qiwL132TWNtOh2hHerudn91hwtb54j4qxA3dldj6FiaC1ofV+tWcBjPEN+w3kPEldGAnSVQoShOkgaE0IkyBQlCdJAySSYlAziq1SqmtlowiVQrWns6RqHM7hxJyAWUQAttol0bm/1HXyGXiV5lt1srSpNNpoy2T36cSySdWH6vTMcI0XfMMNE6nM9TmSqd82cVqNSk7R7SOh1afAwfBWY6HiTgmUjgRkd2qjJlalMgKkATOQBKeU0JQgsFEmack4VAHVStQOCNoQMTC932bs/ZWajTOrabHdHtAJ8ySvDWMkjqF74DDQfsHC7kDmD0gnyVqNztJz4omuWTZaxw4T9XLy09IV2lUV0i3KUqMPSL1AZKbEoi5MHK6E8pSo8SbGgkLlBUenqOVC1V4ViBDbs9Ssq/bTJp0x/MfgPiVRve0HGHAnJVrJXNatjduy/Ll8ZVVsO93q6B0AVO0uICv1G5tbwGfV/9lVtQzPkiPIL6pYa9Uad93kTI+Kz3D1XSbcWTBaAYyewGeJBI+AC5xy1SoAUDiiKRCAE6RShBYKaFIaiIZqiLHyUjXpYULnQckFmyZvYOLmjzcAvfaJgB5Ej/AA6o5DIO+B8V4Hc/er0Rxq0/6wvoCyaxuqNn8QGfp8FlCKjgaby2ZaR3TxA0UlntMOAO8pXjT7kfYzHNv9tPJUw6S08x8VkN2nVzhG4qqw5gqwSgMFEFE0KVoUDlCETkAQQ2l6w7zrZwtW2vzCx7eJniqMascRwnLgUGzrIkHXE4H87kq3NR3XX+kLT18CkK6VgkzvOf6eQVSqyfElXaIJ0TvYxubs+AHL97lUchtjcZrWZzqbS59LviAT3frgeGcfdC8tle7Wuo+o0t9xsQGt4c/wBnwXh9tspp1H0zqxxb+UwtdlVynaExSBWIRCUJnFDmgtsYkTCdpQVHzuVD40OBM3XqpUG3sPYe1tlKSAGHtDP3NAPHD6r3CztBAAOYzB4FeK7B2ynStbX1nhjQ1wBIJEkAAZDmfJex2K2UKuTKtN/IOaT+XULKJg1K9Xo4hl5fELBs4hxYdWuy6aj4LedRy3jxPwWE9hFYk7gM9NZWUI1aWoUzTJUNH3ZU9AIJmNRhIBJYgHlIIXInHJUZ1uKybZkJWjb35LLvJ/dAVVl1syqF51zZ6lN0d0NmpyD3gA+EStazUcTgOfoqO1FIOpWg8MDR+GHH4qK37PaHOGojkP2PRPa7XTotx1XtY3i45u5AauPILya79qbS1gp9u4ACBk2Y4Yon1Vi6KLrTWlznPO9ziXHpJWjJ5HH/AI34vH597dNfe1VRzSLMw02/6jx3z/Kz6vU58l5ta3EvcSSSSSSTJJOcklegX3Z8LYXAW8d8rVhy2vPbZ5GGtKxpXJSCFGCuhxkU2FEShQShIJQk5qobAnZKanmpCguXK2a9Mfe/Vep0QIhwBHAiR6rz3Y2y47S07mAu8dB8T5Lvre0sbi4Lh8mfyeh4sfh9ymfUDB3ZbH2CWf0wpdma1SuarsTnBtQN7zicIDAd53lxXPVbfLdVN7NbwcbRaGfUcGn8QJHwnyWzxpnkx8qIir0MjQK1SbAUVNmasALtlwCQuKKVHVKgAapVSlSUdpdAVGZbTosi2GStGucRWfWEugKyq1c9DMuO7JYe0Amw1X/bcT+Z0D0hdNWHZWZ534SB1OQWVfVnH8NRpfac0ekqT6WPbxUN3Bes7H3F2FEOeIe7MjhwC5b2f7O9tV7eoPo6ToYD9aoN/RvxjgV6LeVoDGrg8i0evh2eNExH25La2qA1ec273p5fNdJtHeBqPjcuYtLpKePXS+VaNaRpEJBOF1uEMppTuTILCZyFjlJCoZo4I5QlCXoO79m9kEVKm8uw+AE/Ndtb6Xd8Fy/s6b9B1c4+sfJdhaBIXBfu0vRp1WribddRa1xG8E9EXstH/kujNvZH1eYW7b2TTI3AERxVH2U2U4LSS1wxObhJaQ1zRjHdOhzJmOS3+N7lq8qdxD0hr5AI0RYlQbaezZDtRlB9FVp3iXcl16cTXFYaKC01NyioA+8ckDXYnK6FumMlSvCrGSvLItneqAJAjLYbKqXdSxOnmrd6HCzCNXZKxdVniBwSVRX/AO7Tp/aeJ6DP9FRv0TWoM4Eu8m/3Vy1O7S1Bu6mAPE5n5IbXQm0Oqk5NaGNHOZcfgPNa724122Y67nQLJZmUaYYwQAMh1zJPMkkrmb/tWKWzzPJbVut0TEAcSvP9o71GbG+J4rzJ3edQ9KkcI3LDvS0iSRpoOax5T16mIzuQMXfSvGHnZb85GAlKJA4rNqOSmSQoJH9E4enOaAmCqJJSAUYz0Rgoj0f2fP8AoQObviV21QZLhdhD9C3qT/uK7Yu7q8+f2t9vTiPxr9M+r3nBmZxGCBrGZMc4BXRWKoKrA2nDMADQBqANAOWS5uzYv4mkRueCeTQDiPlPot68bI6k/tqX4mjeF1+N6mXN5XuIC+7ar3S/z49FdpXa0RO5NZb6a7Iggo6t4N4nyK6e3KG0PLjgYMt5U9Cz4BzTULUw+6QpBVBQNUdAWVZe9UceGSu2yrAVe7AAzFvJJQQWluOtG5g9StGm8U2Oe7IAE+QVCwUnPkjIEklx+SG8pquFESKTSDUccsZGeFvETElY2tEQyiu50guqRNV3vPl2fM5eizL7vkNlrcytG+q4ZTyyHyXC3tbT7rG7pcRr0Xn5sk3nUPRwY4rHKVS+r5IGGVx1otGInNPelZ2NzDlhJBHMaqkt+LFxhzZ83OdR6SJBC0IiVucx3OQtSRFALkOJFKSCwxBUajOWajLlQmNROyRBoTOAQd9sLnTbzxD/AHFduT3YXC7BPml0cV3NodAXnz+9np1/Sv0guVs2h7ie61mHPIS8z/8AHquxADhxXL7O2dlRji9pnG7QxpABjwV+rZa1HvUiXM+zvH6rvxV1SHDnnd5FbLua0kjXUfNVmvxZQrdC/QffZmNY1HUFT07woH7vhC27aVVrcoAzVunSwiSo7Rb6NPNpxO4DNZFqvl5OZA5ZkqhW60lzjwVqm+KYBMYu6OMfWPLLfzWeDjOugk8I66LMrXlWru7Gg08JjUdTu5rVkyceo9t2PFy7n06T/qbR3AQYGTRuG7/kqlXvHKVzleyVLDiFSC55BBBJBBAAE9ZWZfN4YANS45kbmjeVwZLW5al3Y6U1uF3aC+BEEzvjnuHz8ll3e4vLXPyDj3eYGQP6LmrRaTUfPH/hdfXeKVB1UiAynDZ3wIb6x5rbgxxvctXkZJiNQ85t9TFVqO+09xHQuMKEFMShIXS4UrXJ0FMQpC5AJfyTOqJnId6KUlLEUaZBO5yYIkwVQ5CYIyEEIO02BrQCPv8AyC9Dtp7q8x2KmXfdc0+cheiXnWwUy46AT5BcF/6TD0sf86y0dkaJ7IYjOJz3A8i90DyXQikVy9y33Ym02MNss2MNaHMFanIcGie7ikLYN7U/q1aZ6PafmvRiNRp51p3MymtV3B+ZEHis+tdhG5Nab8w6VaXi9g+aw7dtsKetssreRq0ifIFZMW3Ru8Oyd5gEn0UtSx2emDjc0HnGLy1Xnd4+0Wjo62F3Kk15HmBHqsG0e0qi2ezs9So7cargxvWG4ifRTavXLHd9B84GvIOpLnARu0Kxto9uLvuprqdMCrX/ANKkZIP/ALameDxk8l43fW31vtQwOrmlTIjs6I7NscCR3j0mOS5tjQNCsejc607S8PaTbK9YVanZ4ROCjgGBoP3veLuZMclUtG1LXglwfjd72haANA0zJ56LlXTxQEBYWx1tO5bKZrVjUS7nYy0U69qbTJLTBc2QCHlv1RnrGfgV0m3toDKAp4s3vBjfhbmfXCvJrFanUajKtMw9jg5vCRuPI6eK7Taq92WsUKzNCxzXN3seCC5p8weYIVisVjpja029sFzlJTUIRsRiNyCUZCjhAg9IglCGosSBgnhMUpQWyDwTCeCkaURVEReUxeichCDsdhKfcc476jR4AA/MrrNtT/2FocNW03EeAXM7De5+M/Bq63a5o/grRl/lP/pK4rf0l6Nf5Q+fmCdwKPs2/Zb5BDS0UrV6DzVepZhuUQA0IhXXKpWUmALmJoKNqk4qCIpJ6qFiAkxARtUTkChX7tORHOf35LPCvXbv8PmorQATFMhqFQOHJylQCd29AJSlMUkBIpQtTSg//9k=", altText: "Tshirt" }],
    },
    {
      _id: "3",
      name: "Denim Jeans",
      price: 80,
      images: [{ url: "https://picsum.photos/500/500?random=3", altText: "Jeans" }],
    },
    {
      _id: "4",
      name: "Sneakers",
      price: 95,
      images: [{ url: "https://picsum.photos/500/500?random=11", altText: "Shoes" }],
    },
    {
      _id: "5",
      name: "Hoodie",
      price: 70,
      images: [{ url: "https://picsum.photos/500/500?random=5", altText: "Hoodie" }],
    },
    {
      _id: "6",
      name: "Formal Shirt",
      price: 65,
      images: [{ url: "https://picsum.photos/500/500?random=6", altText: "Shirt" }],
    },
    {
      _id: "7",
      name: "Summer Dress",
      price: 110,
      images: [{ url: "https://picsum.photos/500/500?random=7", altText: "Dress" }],
    },
    {
      _id: "8",
      name: "Leather Bag",
      price: 150,
      images: [{ url: "https://picsum.photos/500/500?random=8", altText: "Bag" }],
    },
  ];

  return (
    <section className="py-10 px-4">
      <div className="container mx-auto text-center mb-20 relative">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Explore New Arrivals</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Discover the latest styles straight off the runway, freshly added to keep your wardrobe on the cutting edge of fashion.
        </p>

        {/* Scroll Buttons */}
        <div className="absolute right-0 bottom-[-50px] flex space-x-2">
          <button
            onClick={() => scroll("left")}   // ✅ added
            className="p-3 rounded-lg border bg-white shadow-md hover:shadow-lg transition"
          >
            <HiArrowLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => scroll("right")}  // ✅ added
            className="p-3 rounded-lg border bg-white shadow-md hover:shadow-lg transition"
          >
            <HiArrowRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Horizontal Scrollable Products */}
      <div
        ref={scrollRef}   // ✅ connected scroll
        className="container mx-auto overflow-x-auto scrollbar-hide pb-8 scroll-smooth"
      >
        <div className="flex space-x-6">
          {newArrivals.map((product) => (
            <div
              key={product._id}
              className="min-w-[280px] flex-shrink-0 relative group cursor-pointer"
            >
              <img
                src={product.images[0]?.url}
                alt={product.images[0]?.altText || product.name}
                className="w-full h-[450px] object-cover rounded-2xl shadow-xl group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6 rounded-b-2xl">
                <Link to={`/product/${product._id}`} className="block">
                  <h4 className="font-semibold text-xl text-white mb-1">{product.name}</h4>
                  <p className="text-2xl font-bold text-white">${product.price}</p>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewArrivals;
