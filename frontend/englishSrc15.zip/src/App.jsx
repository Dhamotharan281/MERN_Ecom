// import React from "react";
// import { BrowserRouter, Routes, Route } from "react-router-dom";
// import UserLayout from "./components/Layout/UserLayout";
// import Home from "./pages/Home";
import React from "react";
import { BrowserRouter, Routes, Route, useParams } from "react-router-dom";
import UserLayout from "./components/Layout/UserLayout";
import Home from "./pages/Home";

const ProductDetails = () => {
  const { id } = useParams();

  return (
    <div className="p-10 text-center">
      <h1 className="text-3xl font-bold">Product Details</h1>
      <p className="text-lg mt-4">Product ID: {id}</p>
       <ScrollTopLogo />
    </div>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<UserLayout />}>
          <Route index element={<Home />} />

          {/* ✅ THIS IS WHAT YOU ARE MISSING */}
          {/* <Route path="product/:id" element={<ProductDetails />} /> */}

        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;




